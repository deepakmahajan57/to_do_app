import React, { useEffect, useState } from "react";
const defaultValue = {
  title: "",
  desc: "",
};

const Modal = ({ isVisible, onClose, item, index }) => {
  const [demoUser, setDemoUser] = useState(defaultValue);
  console.log("itemmmmmmmmmmmmmm");
  console.log(item);
  console.log(index);
  console.log("itemmmmmmmmmmmmmm");
  useEffect(() => {
    setDemoUser({ title: item.title, desc: item.desc });
  }, []);

  console.log("demouser..", demoUser);
  const [user, setUser] = useState({
    title: "",
    desc: "",
  });
  // setUser({ title: item.index, desc: item.desc });
  console.log("user is..", user);
  // const [demoItem, setDemoItem] = useState([]);
  // const [title, setTitle] = useState("");
  // const [desc, setDesc] = useState("");
  if (!isVisible) return null;
  console.log("model item is", item);
  console.log("index item is", index);
  var count = 0;
  // item.map((element) => {
  //   console.log("array element", element);
  //   if (element.sno === index) {
  //     console.log("index is", index, " title is", element.title);
  //     // setUser({
  //     //   ...user,
  //     //   title: element.title,
  //     //   desc: element.desc,
  //     // });
  //     console.log("item of 1 is./..", item[1]);
  //     console.log("count is is./..", count);
  //   }
  //   count++;
  // });

  //
  // setDemoItem(item[count]);
  // console.log("demo item, ", demoItem);
  // setUser({
  //   ...user,
  //   title: item[count].title,
  //   desc: item[count].desc,
  // });
  console.log("user a is ./.", user);

  const submit = (e) => {
    //   e.preventDefault();
    //   if (!title || !desc) {
    //     alert("Title or desc cannot be blank");
    //   } else {
    //     // props.addTodo(title, desc);
    //     setTitle(item.title);
    //     setDesc(item.desc);
    //   }
  };
  const onValueChangeDisk = (e) => {};
  const onValueChange = (e) => {
    console.log("oncange demouser", demoUser);
    setDemoUser({
      ...demoUser,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-25 backdrop-blur-sm flex justify-center items-center">
        <div className="w-1/2 flex flex-col">
          <button
            className="text-white text-xl place-self-end"
            onClick={() => {
              onClose();
            }}
          >
            {" "}
            X
          </button>
          <div className="bg-white p-2 rounded">
            Model
            <form onSubmit={submit}>
              <label for="input" class="block text-gray-700 font-bold mb-2">
                Title
              </label>
              <input
                type="text"
                id="input"
                name="title"
                class="border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                value={demoUser.title}
                onChange={(e) => onValueChange(e)}
              />
              <label for="task" class="block text-gray-700 font-bold mb-2">
                Task
              </label>
              <input
                type="text"
                id="desc"
                name="desc"
                class="border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                value={demoUser.desc}
                onChange={(e) => onValueChangeDisk(e)}
              />
              <br />
              <button
                type="submit"
                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded my-3"
              >
                Update
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default Modal;

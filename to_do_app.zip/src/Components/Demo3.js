import { useState } from "react";

function Demo3() {
  const [todos, setTodos] = useState([
    { id: 1, text: "Finish homework", completed: false },
    { id: 2, text: "Clean room", completed: true },
    { id: 3, text: "Buy groceries", completed: false },
  ]);
  const [newTodoText, setNewTodoText] = useState("");

  const handleNewTodoChange = (event) => {
    setNewTodoText(event.target.value);
  };

  const handleAddTodo = () => {
    if (newTodoText !== "") {
      const newTodo = {
        id: todos.length + 1,
        text: newTodoText,
        completed: false,
      };
      setTodos([...todos, newTodo]);
      setNewTodoText("");
    }
  };

  const handleTodoToggle = (id) => {
    const updatedTodos = todos.map((todo) => {
      if (todo.id === id) {
        return { ...todo, completed: !todo.completed };
      } else {
        return todo;
      }
    });
    setTodos(updatedTodos);
  };

  const handleTodoDelete = (id) => {
    const updatedTodos = todos.filter((todo) => todo.id !== id);
    setTodos(updatedTodos);
  };

  return (
    <div className="container mx-auto max-w-md">
      <h1 className="text-2xl font-bold mb-4">Todo List</h1>
      <div className="flex mb-4">
        <input
          type="text"
          className="w-full p-2 border border-gray-400 rounded"
          placeholder="Add a new todo"
          value={newTodoText}
          onChange={handleNewTodoChange}
        />
        <button
          className="bg-blue-500 text-white font-bold py-2 px-4 ml-2 rounded"
          onClick={handleAddTodo}
        >
          Add
        </button>
      </div>
      <ul>
        {todos.map((todo) => (
          <li
            key={todo.id}
            className="flex justify-between items-center p-2 border-b border-gray-400"
          >
            <div className={todo.completed ? "line-through" : ""}>
              {todo.text}
            </div>
            <div>
              <input
                type="checkbox"
                checked={todo.completed}
                onChange={() => handleTodoToggle(todo.id)}
              />
              <button
                className="bg-red-500 text-white font-bold py-1 px-2 ml-2 rounded"
                onClick={() => handleTodoDelete(todo.id)}
              >
                Delete
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Demo3;

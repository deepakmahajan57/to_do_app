import React, { useState } from "react";
import Modal from "./Modal";

const Todos = (props) => {
  const [showModel, setShowModel] = useState(false);
  const [index, setIndex] = useState("");

  let myStyle = {
    minHeight: "60vh",
  };
  var count = 0;
  props.todos.map((element) => {
    console.log("array todo element", element);
    if (element.sno === index) {
      console.log("index in todo is", index, " title is", element.title);
      console.log("props.todo in todo is./..", props.todos);
      console.log("count in todo is./..", count);
    }
    count++;
  });
  let propsPass = props.todos;
  console.log("props.todo[1]..", props.todos[1]);

  return (
    <>
      <div className="container" style={myStyle}>
        <h3>Todos List</h3>

        {props.todos.length === 0 ? (
          "No Todo to display"
        ) : (
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th
                  scope="col"
                  class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Title
                </th>
                <th
                  scope="col"
                  class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Descripton
                </th>
                <th
                  scope="col"
                  class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  TimeStamp
                </th>
                <th
                  scope="col"
                  class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Status
                </th>{" "}
                <th
                  scope="col"
                  class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Action
                </th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
              {props.todos.map((item) => (
                <tr key={item.id}>
                  <td class="px-6 py-4 whitespace-nowrap">{item.title}</td>
                  <td class="px-6 py-4 whitespace-nowrap">{item.desc}</td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    date: {item.date}
                    <br />
                    time: {item.time}
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">{item.status}</td>

                  <td class="px-6 py-4 whitespace-nowrap">
                    <button
                      class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mx-3"
                      onClick={() => {
                        setShowModel(true);
                        setIndex(item.sno);
                      }}
                    >
                      Edit
                    </button>

                    <button
                      class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
                      onClick={() => {
                        props.onDelete(item);
                      }}
                    >
                      delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      <Modal
        isVisible={showModel}
        item={propsPass}
        index={index}
        onClose={() => {
          setShowModel(false);
        }}
      />
    </>
  );
};

export default Todos;

import React, { useState } from "react";
import Modal from "./Modal";

const Demotry = (props) => {
  // const [showModel, setShowModel] = useState(false);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");

  function handleDateChange(e) {
    setDate(e.target.value);
  }

  function handleTimeChange(e) {
    setTime(e.target.value);
  }

  function handleSubmit(e) {
    e.preventDefault();
    console.log(`Date: ${date}, Time: ${time}`);
  }
  return (
    <>
      <form onSubmit={handleSubmit}>
        <label htmlFor="date" className="block font-medium text-gray-700">
          Date
        </label>
        <input
          id="date"
          type="date"
          value={date}
          onChange={handleDateChange}
          className="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
        />
        <label htmlFor="time" className="block mt-4 font-medium text-gray-700">
          Time
        </label>
        <input
          id="time"
          type="time"
          value={time}
          onChange={handleTimeChange}
          className="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
        />
        <button
          type="submit"
          className="mt-4 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
        >
          Submit
        </button>
      </form>
      {/* // tabel with pagination */}
      <div class="container mx-auto">
        <table class="table-auto w-full">
          <thead>
            <tr>
              <th class="px-4 py-2">Name</th>
              <th class="px-4 py-2">Email</th>
              <th class="px-4 py-2">Phone</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="border px-4 py-2">John Doe</td>
              <td class="border px-4 py-2">johndoe@example.com</td>
              <td class="border px-4 py-2">123-456-7890</td>
            </tr>
            <tr>
              <td class="border px-4 py-2">Jane Doe</td>
              <td class="border px-4 py-2">janedoe@example.com</td>
              <td class="border px-4 py-2">555-555-5555</td>
            </tr>
            {/* <!-- More table rows --> */}
            <tr class="hidden">
              <td class="border px-4 py-2">John Smith</td>
              <td class="border px-4 py-2">johnsmith@example.com</td>
              <td class="border px-4 py-2">555-123-4567</td>
            </tr>
            <tr class="hidden">
              <td class="border px-4 py-2">Jane Smith</td>
              <td class="border px-4 py-2">janesmith@example.com</td>
              <td class="border px-4 py-2">555-987-6543</td>
            </tr>
            <tr class="hidden">
              <td class="border px-4 py-2">John Doe Jr.</td>
              <td class="border px-4 py-2">johndoejr@example.com</td>
              <td class="border px-4 py-2">123-456-7890</td>
            </tr>
          </tbody>
        </table>
        <div class="flex justify-center py-4">
          <a
            href="#"
            class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-l prev"
          >
            Previous
          </a>
          <a
            href="#"
            class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-r next"
          >
            Next
          </a>
        </div>
      </div>
    </>
  );
};

export default Demotry;

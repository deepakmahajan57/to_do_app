import "./App.css";
import AddTodo from "./Components/AddTodo";
import Footre from "./Components/Footre";
// import TodoItem from "./Components/TodoItem";
import NavBar from "./Components/NavBar";
import Todos from "./Components/Todos";
import React, { useState, useEffect } from "react";
import Demotry from "./Components/Demotry";
import Modal from "./Components/Modal";
// import Demo2 from "./Components/Demo2";
import Demo3 from "./Components/Demo3";
import Table from "./Components/Table";

function App() {
  let initTodo;
  if (localStorage.getItem("todos") === null) {
    initTodo = [];
  } else {
    initTodo = JSON.parse(localStorage.getItem("todos"));
  }
  const onDelete = (todo) => {
    console.log("i am on delete", todo);

    setTodos(
      todos.filter((e) => {
        return e !== todo;
      })
    );
    localStorage.setItem("todos", JSON.stringify(todos));
  };

  const addTodo = (title, desc, status, date, time) => {
    console.log("t amn add todod", title, desc, status, date, time);
    let sno;
    if (todos.length === 0) {
      sno = 0;
    } else {
      sno = todos[todos.length - 1].sno + 1;
    }
    const myTodo = {
      sno: sno,
      title: title,
      desc: desc,
      status: status,
      date: date,
      time: time,
    };
    setTodos([...todos, myTodo]);
    console.log(myTodo);
  };

  const [todos, setTodos] = useState(initTodo);

  useEffect(() => {
    localStorage.setItem("todos", JSON.stringify(todos));
  }, [todos]);

  return (
    <>
      <NavBar />
      <AddTodo addTodo={addTodo} />
      <Todos todos={todos} onDelete={onDelete} onEdit={<Modal />} />
      {/* <TodoItem /> */}
      <Footre />
      <Demotry />
      {/* <Demo2 /> */}
      <Demo3 />
      {/* <Table /> */}
    </>
  );
}

export default App;

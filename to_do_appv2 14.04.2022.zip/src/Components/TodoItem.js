import React from "react";

const TodoItem = (title, desc, todo, onDelete) => {
  console.log("todo is", todo);
  //   console.log("todo .todo ", todo.todo);
  console.log("title is...", title);
  console.log("desc is...", title.desc);

  return (
    <div>
      <h4>{title.title}</h4>
      <p>{title.desc}</p>
      <button
        class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
        onClick={() => {
          onDelete(title);
        }}
      >
        Delete
      </button>
      {/* // table creation */}
      {/* <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
          <tr>
            <th
              scope="col"
              class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Title
            </th>
            <th
              scope="col"
              class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Description
            </th>
            <th
              scope="col"
              class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Action
            </th>
          </tr>
        </thead>
        <tbody class="bg-white divide-y divide-gray-200">
          <tr>
            <td class="px-6 py-4 whitespace-nowrap">{title.title}</td>
            <td class="px-6 py-4 whitespace-nowrap">{title.desc}</td>
            <td class="px-6 py-4 whitespace-nowrap">
              <button
                class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
                onClick={() => {
                  onDelete(title);
                }}
              >
                Delete
              </button>
            </td>
          </tr>
        </tbody>
      </table> */}
    </div>
  );
};

export default TodoItem;

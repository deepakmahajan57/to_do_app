import React from "react";
import { useState, useEffect } from "react";
const Demo2 = () => {
  const [numInputs, setNumInputs] = useState(0);

  useEffect(() => {
    const inputContainer = document.getElementById("input-container");
    inputContainer.innerHTML = ""; // Clear existing input boxes

    for (let i = 0; i < numInputs; i++) {
      const inputBox = document.createElement("input");
      inputBox.setAttribute("type", "text");
      inputBox.setAttribute("placeholder", "Enter text...");
      inputBox.classList.add(
        "mt-2",
        "p-2",
        "border",
        "border-gray-300",
        "rounded"
      );

      inputContainer.appendChild(inputBox);
    }
  }, [numInputs]);

  return (
    <>
      <h1>demo 2</h1>
      <div className="flex flex-col items-center">
        <button
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
          onClick={() => setNumInputs(numInputs + 1)}
        >
          Add Input Box
        </button>
        <div id="input-container" className="mt-4"></div>
      </div>
    </>
  );
};

export default Demo2;

import React, { useState, useEffect } from "react";
import ReactPaginate from "react-paginate";

const Table = () => {
  const [tableData, setTableData] = useState([]);
  const [pageNumber, setPageNumber] = useState(0);
  const [pageSize, setPageSize] = useState(5);
  const [pageCount, setPageCount] = useState(0);

  const handlePageClick = (data) => {
    setPageNumber(data.selected);
  };

  useEffect(() => {
    // Fetch table data from API or other source
    const fetchData = async () => {
      const response = await fetch(
        `https://api.example.com/data?page=${pageNumber}&pageSize=${pageSize}`
      );
      const json = await response.json();
      setTableData(json.data);
      setPageCount(json.pageCount);
    };
    fetchData();
  }, [pageNumber, pageSize]);

  return (
    <div className="flex flex-col">
      <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
        <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
          <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Name
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Age
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Email
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Salary
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {/* {tableData.map((row) => (
                  <tr key={row.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {row.name}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">{row.age}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">{row.email}</div>
                    </td>
                  </tr>
                ))} */}
                <tr>
                  <td>001</td>
                  <td>Anusha</td>
                  <td>India</td>
                  <td>10000</td>
                </tr>
                <tr>
                  <td>002</td>
                  <td>Charles</td>
                  <td>United Kingdom</td>
                  <td>28000</td>
                </tr>
                <tr>
                  <td>003</td>
                  <td>Sravani</td>
                  <td>Australia</td>
                  <td>7000</td>
                </tr>
                <tr>
                  <td>004</td>
                  <td>Amar</td>
                  <td>India</td>
                  <td>18000</td>
                </tr>
                <tr>
                  <td>005</td>
                  <td>Lakshmi</td>
                  <td>India</td>
                  <td>12000</td>
                </tr>
                <tr>
                  <td>006</td>
                  <td>James</td>
                  <td>Canada</td>
                  <td>50000</td>
                </tr>

                <tr>
                  <td>007</td>
                  <td>Ronald</td>
                  <td>US</td>
                  <td>75000</td>
                </tr>
                <tr>
                  <td>008</td>
                  <td>Mike</td>
                  <td>Belgium</td>
                  <td>100000</td>
                </tr>
                <tr>
                  <td>009</td>
                  <td>Andrew</td>
                  <td>Argentina</td>
                  <td>45000</td>
                </tr>

                <tr>
                  <td>010</td>
                  <td>Stephen</td>
                  <td>Austria</td>
                  <td>30000</td>
                </tr>
                <tr>
                  <td>011</td>
                  <td>Sara</td>
                  <td>China</td>
                  <td>750000</td>
                </tr>
                <tr>
                  <td>012</td>
                  <td>JonRoot</td>
                  <td>Argentina</td>
                  <td>65000</td>
                </tr>
              </tbody>
            </table>
            <ReactPaginate
              pageCount={pageCount}
              onPageChange={handlePageClick}
              containerClassName="flex justify-center my-4"
              pageClassName="mx-2"
              activeClassName="text-blue-600 font-medium"
              breakClassName="mx-2"
              previousLabel="<"
              nextLabel=">"
              marginPagesDisplayed={2}
              pageRangeDisplayed={5}
              disableInitialCallback={true}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Table;

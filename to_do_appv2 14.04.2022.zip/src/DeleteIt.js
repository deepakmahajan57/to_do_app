import React, { useState } from "react";
import Data from "./Data.json";
import { FirstPage } from "@mui/icons-material";

const DeleteIt = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const recordsPerPage = 5;
  const lastIndex = currentPage * recordsPerPage;
  const firstIndex = lastIndex - recordsPerPage;
  const records = Data.slice(firstIndex, lastIndex);
  const npages = Math.ceil(Data.length / recordsPerPage);
  const numbers = [...Array(npages + 1).keys()].slice(1);
  const prePage = () => {
    if (currentPage !== 1) {
      setCurrentPage(currentPage - 1);
    }
  };
  const changeCPage = (id) => {
    setCurrentPage(id);
  };
  const nextPage = () => {};
  if (currentPage !== npages) {
    setCurrentPage(currentPage + 1);
  }
  return (
    <>
      <div>
        <table>
          <thead>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
          </thead>
          <tbody>
            {records.map((d, i) => (
              <tr key={i}>
                <td>{d.Id}</td>
                <td>{d.Name}</td>
                <td>{d.emaild}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {/*       
        <button className="bg-blue-600">Prev</button>
        {numbers.map((n, i) => (
          <button className="bg-blue-600 mx-3" onClick={() => changeCPage(n)}>
            {n}
          </button>

          //   <li className={currentPage === n ? "active" : ""} key={i}>
          //     <a href="#" onClick={() => changeCPage(n)}>
          //       {n}
          //     </a>
          //   </li>
        ))}
        <button className="bg-pink-600 mx-3">Next</button> */}

        <nav>
          <ul className="">
            <li>
              <a href="#" className="bg-pink-600" onClick={prePage}>
                Prev
              </a>
            </li>
            {numbers.map((n, i) => (
              <li className={currentPage === n ? "active" : ""} key={i}>
                <a
                  className="bg-pink-600"
                  href="#"
                  onClick={() => changeCPage(n)}
                >
                  {n}
                </a>
              </li>
            ))}
            <li>
              <a href="#" className="bg-pink-600" onClick={nextPage}>
                Next
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </>
  );
};

export default DeleteIt;

import React, { useState } from "react";
import Data from "./Data.json";

const PaginationTable = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const recordsPerPage = 5;
  const lastIndex = currentPage * recordsPerPage;
  const firstIndex = lastIndex - recordsPerPage;
  const records = Data.slice(firstIndex, lastIndex);
  const totalPages = Math.ceil(Data.length / recordsPerPage);
  const pageNumbers = [...Array(totalPages).keys()].map((num) => num + 1);

  const nextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const previousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  return (
    <>
      <div>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
            </tr>
          </thead>
          <tbody>
            {records.map((d, i) => (
              <tr key={i}>
                <td>{d.id}</td>
                <td>{d.name}</td>
                <td>{d.email}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <h1>111111</h1>
        <button
          className="bg-pink-600"
          onClick={previousPage}
          disabled={currentPage === 1}
        >
          Prev
        </button>
        {pageNumbers.map((num) => (
          <button
            className="bg-pink-600 mx-3 px-2"
            onClick={() => setCurrentPage(num)}
          >
            {num}
          </button>
         
        ))}
        <button
          className="bg-pink-600 "
          onClick={nextPage}
          disabled={currentPage === totalPages}
        >
          Next
        </button>
        <h1>2222</h1>

        {/* <nav>
          <ul className="">
            <li>
              <button
                className="bg-pink-600"
                onClick={previousPage}
                disabled={currentPage === 1}
              >
                Prev
              </button>
            </li>
            {pageNumbers.map((num) => (
              <li key={num} className={num === currentPage ? "active" : ""}>
                <button
                  className="bg-pink-600"
                  onClick={() => setCurrentPage(num)}
                >
                  {num}
                </button>
              </li>
            ))}
            <li>
              <button
                className="bg-pink-600"
                onClick={nextPage}
                disabled={currentPage === totalPages}
              >
                Next
              </button>
            </li>
          </ul>
        </nav> */}

      </div>
    </>
  );
};

export default PaginationTable;

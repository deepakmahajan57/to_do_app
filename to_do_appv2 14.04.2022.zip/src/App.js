import "./App.css";
import AddTodo from "./Components/AddTodo";
import Footre from "./Components/Footre";
// import TodoItem from "./Components/TodoItem";
import NavBar from "./Components/NavBar";
import Todos from "./Components/Todos";
import React, { useState, useEffect } from "react";
import Demotry from "./Components/Demotry";
import Modal from "./Components/Modal";
// import Demo2 from "./Components/Demo2";
import Demo3 from "./Components/Demo3";
import Table from "./Components/Table";
import TableDemo from "./Components/TableDemo";
import EnhancedTable from "./Components/EnhancedTable";
import DeleteIt from "./DeleteIt";
import PaginationTable from "./PaginationTable";

function App() {
  let initTodo;
  if (localStorage.getItem("todos") === null) {
    initTodo = [];
  } else {
    initTodo = JSON.parse(localStorage.getItem("todos"));
  }
  const onDelete = (todo) => {
    const confirmDelete = window.confirm("Are you sure you want to delete?");
    if (confirmDelete) {
      // delete code here

      console.log("i am on delete", todo);

      setTodos(
        todos.filter((e) => {
          return e !== todo;
        })
      );
      localStorage.setItem("todos", JSON.stringify(todos));
    }
  };

  const addTodo = (title, desc, status, date, time) => {
    console.log("t amn add todod", title, desc, status, date, time);
    let sno;
    if (todos.length === 0) {
      sno = 0;
    } else {
      sno = todos[todos.length - 1].sno + 1;
    }
    const myTodo = {
      sno: sno,
      title: title,
      desc: desc,
      status: status,
      date: date,
      time: time,
    };
    setTodos([...todos, myTodo]);
    console.log(myTodo);
  };

  const [todos, setTodos] = useState(initTodo);

  useEffect(() => {
    localStorage.setItem("todos", JSON.stringify(todos));
  }, [todos]);

  return (
    <>
      {/* <NavBar /> */}
      <div class="flex">
        <div class="w-1/4 bg-slate-500">
          {" "}
          <AddTodo addTodo={addTodo} />
        </div>
        <div class="w-9/12 bg-red-500 px-3">
          {" "}
          <Todos todos={todos} onDelete={onDelete} onEdit={<Modal />} />
        </div>
      </div>
      {/* <TodoItem /> */}
      {/* <Footre /> */}
      {/* <Demotry /> */}
      {/* <Demo2 /> */}
      {/* <Demo3 /> */}
      <h1>table printing</h1>
      <Table />
      <TableDemo />
      <h1>enhanced table</h1>
      {/* <EnhancedTable /> */}
      <div class="flex">
        <div class="w-1/4 bg-slate-500">First div</div>
        <div class="w-9/12 bg-red-500">Second div</div>
      </div>
      <DeleteIt />

      <h1>pagination table</h1>
      <PaginationTable />
    </>
  );
}

export default App;

import React from "react";

const Footre = () => {
  return (
    <>
      <p>All right reserved</p>
    </>
  );
};

export default Footre;

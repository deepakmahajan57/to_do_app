// import React, { useMemo, useState } from "react";
// import { useTable, useGlobalFilter, usePagination } from "react-table";
// // import { globalFilterr } from './globalFilterr';
// import ReactPaginate from "react-paginate";

// function Table({ columns, data }) {
//   const [pageNumber, setPageNumber] = useState(0);
//   const [globalFilterr, setGlobalFilterr1] = useState("");

//   const {
//     getTableProps,
//     getTableBodyProps,
//     headerGroups,
//     rows,
//     prepareRow,
//     state,

//     pageOptions,
//     pageCount,
//     gotoPage,
//     nextPage,
//     previousPage,
//     canNextPage,
//     canPreviousPage,
//     page,
//     state: { pageIndex },
//   } = useTable(
//     {
//       columns,
//       data,
//       initialState: { pageIndex: 0 },
//     },
//     useGlobalFilter,
//     usePagination
//   );

//   const handlePageClick = ({ selected }) => {
//     setPageNumber(selected);
//   };

//   const displayedRows = useMemo(() => {
//     return rows.filter((row) => {
//       return Object.values(row.original)
//         .join("")
//         .toLowerCase()
//         .includes(globalFilterr.toLowerCase());
//     });
//   }, [globalFilterr, rows]);

//   const handleChangeGlobalFilter = (value) => {
//     setPageNumber(0);
//     setGlobalFilterr1(value);
//   };

//   return (
//     <>
//       <globalFilterr
//         filter={globalFilterr}
//         setFilter={handleChangeGlobalFilter}
//       />
//       <table {...getTableProps()} className="table-auto border-collapse w-full">
//         <thead className="bg-gray-200">
//           {headerGroups.map((headerGroup) => (
//             <tr
//               {...headerGroup.getHeaderGroupProps()}
//               className="border-b-2 border-gray-400"
//             >
//               {headerGroup.headers.map((column) => (
//                 <th
//                   {...column.getHeaderProps()}
//                   className="p-2 text-left font-semibold text-gray-700 uppercase"
//                 >
//                   {column.render("Header")}
//                 </th>
//               ))}
//             </tr>
//           ))}
//         </thead>
//         <tbody {...getTableBodyProps()}>
//           {displayedRows.map((row, i) => {
//             prepareRow(row);
//             return (
//               <tr {...row.getRowProps()} className="border-b border-gray-400">
//                 {row.cells.map((cell) => {
//                   return (
//                     <td {...cell.getCellProps()} className="p-2 text-gray-700">
//                       {cell.render("Cell")}
//                     </td>
//                   );
//                 })}
//               </tr>
//             );
//           })}
//         </tbody>
//       </table>
//       <div className="flex justify-between items-center mt-4">
//         <div className="text-gray-700">
//           Showing {pageIndex * page.length + 1} to{" "}
//           {pageIndex * page.length + page.length > data.length
//             ? data.length
//             : pageIndex * page.length + page.length}{" "}
//           of {data.length} entries
//         </div>
//         <ReactPaginate
//           previousLabel={"previous"}
//           nextLabel={"next"}
//           breakLabel={"..."}
//           breakClassName={"break-me"}
//           pageCount={pageCount}
//           marginPagesDisplayed={2}
//           pageRangeDisplayed={5}
//           onPageChange={handlePageClick}
//           containerClassName={"pagination"}
//           activeClassName={"active"}
//           previousClassName={!canPreviousPage ? "disabled" : ""}
//           nextClassName={!canNextPage ? "disabled" : ""}
//         />
//       </div>
//     </>
//   );
// }

// export default Table;
